import asyncio
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command, StateFilter
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from datetime import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from aiogram.utils.keyboard import InlineKeyboardBuilder
import locale

# === НАСТРОЙКИ ===
BOT_TOKEN = '7555630505:AAGWtcMBE5CBkRVz-fzc8En9X7BEFIr3qiQ'
ADMIN_ID = 6577960531  # ← твой Telegram ID
SPREADSHEET_URL = 'https://docs.google.com/spreadsheets/d/1Y7qoBeIgaHHVFsgo6RRczl3vJu7oaj6FZM4zeh8n5Bg/edit'

# === ПОДКЛЮЧЕНИЕ К GOOGLE SHEETS ===
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("C:/Users/nurs2/OneDrive/Рабочий стол/credentials.json", scope)
client = gspread.authorize(creds)
sheet = client.open_by_url(SPREADSHEET_URL).sheet1

# === БОТ И СОСТОЯНИЯ ===
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

perfumes = {
    'male': [
        {'name': 'Creed Aventus', 'description': 'Ananas, Bergamot, Musk'},
        {'name': 'Dior Sauvage', 'description': 'Bergamot, Pepper, Patchouli'},
        {'name': 'Tom Ford Oud Wood', 'description': 'Oud, Sandalwood, Amber'}
    ],
    'female': [
        {'name': 'Chanel Coco Mademoiselle', 'description': 'Orange, Jasmine, Vanilla'},
        {'name': 'Lancôme La Vie Est Belle', 'description': 'Iris, Vanilla, Praline'},
        {'name': 'Yves Saint Laurent Libre', 'description': 'Lavender, Vanilla, Amber'}
    ]
}

volumes = [5, 10, 50, 100]  # мл

class OrderForm(StatesGroup):
    product = State()
    volume = State()
    delivery = State()
    name = State()
    phone = State()
    city = State()
    address = State()
    lang = State()

user_langs = {}

texts = {
    "ru": {
        "welcome": "Привет! Выберите язык / Тілді таңдаңыз:",
        "choose_lang": "Выберите язык / Тілді таңдаңыз",
        "catalog": "Выберите категорию:",
        "male": "Мужской парфюм",
        "female": "Женский парфюм",
        "volume": "Выберите объём:",
        "delivery": "Выберите способ доставки:",
        "name": "Введите ваше имя:",
        "phone": "Введите номер телефона:",
        "city": "Введите город:",
        "address": "Введите адрес (улица, дом, кв):",
        "done": "Спасибо! Заказ принят.",
        "admin_panel": "Панель администратора",
        "open_sheet": "📁 Открыть таблицу"
    },
    "kz": {
        "welcome": "Сәлем! Тілді таңдаңыз / Выберите язык:",
        "choose_lang": "Тілді таңдаңыз / Выберите язык",
        "catalog": "Санатты таңдаңыз:",
        "male": "Ерлер парфюмі",
        "female": "Әйелдер парфюмі",
        "volume": "Көлемін таңдаңыз:",
        "delivery": "Жеткізу түрін таңдаңыз:",
        "name": "Атыңызды енгізіңіз:",
        "phone": "Телефон нөмірін енгізіңіз:",
        "city": "Қаланы енгізіңіз:",
        "address": "Мекенжайыңызды енгізіңіз (көшесі, үйі, пәтері):",
        "done": "Рақмет! Тапсырыс қабылданды.",
        "admin_panel": "Әкімші панелі",
        "open_sheet": "📁 Кестені ашу"
    }
}

def t(lang, key):
    return texts.get(lang, texts['ru'])[key]

@dp.message(Command("start"))
async def start(message: Message, state: FSMContext):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Русский", callback_data="lang_ru"),
         InlineKeyboardButton(text="Қазақша", callback_data="lang_kz")]
    ])
    await message.answer("Привет! Выберите язык / Тілді таңдаңыз:", reply_markup=keyboard)
    await state.set_state(OrderForm.lang)

@dp.callback_query(F.data.startswith("lang_"))
async def set_lang(callback: CallbackQuery, state: FSMContext):
    lang = callback.data.split("_")[1]
    user_langs[callback.from_user.id] = lang
    await callback.message.answer(t(lang, "catalog"), reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t(lang, "male"), callback_data='male')],
        [InlineKeyboardButton(text=t(lang, "female"), callback_data='female')]
    ]))
    await callback.answer()

@dp.message(Command("admin"))
async def admin_panel(message: Message):
    if message.from_user.id != ADMIN_ID:
        return await message.answer("Доступ запрещён")
    lang = user_langs.get(message.from_user.id, 'ru')
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t(lang, "open_sheet"), url=SPREADSHEET_URL)]
    ])
    await message.answer(t(lang, "admin_panel"), reply_markup=keyboard)

@dp.message(Command("catalog"))
async def catalog(message: Message):
    lang = user_langs.get(message.from_user.id, 'ru')
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t(lang, "male"), callback_data='male')],
        [InlineKeyboardButton(text=t(lang, "female"), callback_data='female')]
    ])
    await message.answer(t(lang, "catalog"), reply_markup=keyboard)

@dp.callback_query(F.data.in_(['male', 'female']))
async def show_perfumes(callback: CallbackQuery):
    lang = user_langs.get(callback.from_user.id, 'ru')
    category = callback.data
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=perfume['name'], callback_data=f"order_{perfume['name'].replace(' ', '_')}")]
        for perfume in perfumes[category]
    ])
    await callback.message.edit_text(f"{t(lang, 'volume')}", reply_markup=keyboard)
    await callback.answer()

@dp.callback_query(F.data.startswith('order_'))
async def choose_volume(callback: CallbackQuery, state: FSMContext):
    product_name = callback.data.replace('order_', '').replace('_', ' ')
    await state.update_data(product=product_name)
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"{v} мл", callback_data=f"volume_{v}")] for v in volumes
    ])
    await callback.message.answer("Выберите объём:", reply_markup=keyboard)
    await state.set_state(OrderForm.volume)
    await callback.answer()

@dp.callback_query(F.data.startswith("volume_"), StateFilter(OrderForm.volume))
async def choose_delivery(callback: CallbackQuery, state: FSMContext):
    volume = callback.data.replace('volume_', '')
    await state.update_data(volume=volume)
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Межгород (Казпочта)", callback_data='delivery_kazpost')],
        [InlineKeyboardButton(text="Город (Яндекс)", callback_data='delivery_yandex')]
    ])
    await callback.message.answer("Выберите способ доставки:", reply_markup=keyboard)
    await state.set_state(OrderForm.delivery)
    await callback.answer()

@dp.callback_query(StateFilter(OrderForm.delivery))
async def ask_name(callback: CallbackQuery, state: FSMContext):
    await state.update_data(delivery='Казпочта' if callback.data == 'delivery_kazpost' else 'Яндекс Доставка')
    lang = user_langs.get(callback.from_user.id, 'ru')
    await callback.message.answer(t(lang, "name"))
    await state.set_state(OrderForm.name)
    await callback.answer()

@dp.message(StateFilter(OrderForm.name))
async def ask_phone(message: Message, state: FSMContext):
    await state.update_data(name=message.text)
    lang = user_langs.get(message.from_user.id, 'ru')
    await message.answer(t(lang, "phone"))
    await state.set_state(OrderForm.phone)

@dp.message(StateFilter(OrderForm.phone))
async def ask_city(message: Message, state: FSMContext):
    await state.update_data(phone=message.text)
    lang = user_langs.get(message.from_user.id, 'ru')
    await message.answer(t(lang, "city"))
    await state.set_state(OrderForm.city)

@dp.message(StateFilter(OrderForm.city))
async def ask_address(message: Message, state: FSMContext):
    await state.update_data(city=message.text)
    lang = user_langs.get(message.from_user.id, 'ru')
    await message.answer(t(lang, "address"))
    await state.set_state(OrderForm.address)

@dp.message(StateFilter(OrderForm.address))
async def finish_order(message: Message, state: FSMContext):
    await state.update_data(address=message.text)
    data = await state.get_data()
    lang = user_langs.get(message.from_user.id, 'ru')
    order_text = (
        f"Новый заказ\n"
        f"Товар: {data['product']} ({data['volume']} мл)\n"
        f"Доставка: {data['delivery']}\n"
        f"Имя: {data['name']}\n"
        f"Телефон: {data['phone']}\n"
        f"Город: {data['city']}\n"
        f"Адрес: {data['address']}"
    )
    await bot.send_message(chat_id=ADMIN_ID, text=order_text)
    sheet.append_row([
        datetime.now().strftime("%Y-%m-%d %H:%M"),
        data['name'],
        data['phone'],
        data['city'],
        data['address'],
        data['product'],
        data['volume'],
        data['delivery']
    ])
    await message.answer(t(lang, "done"))
    await state.clear()

async def main():
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())